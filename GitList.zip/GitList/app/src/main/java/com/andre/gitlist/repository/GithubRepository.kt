package com.andre.gitlist.repository

//class GithubRepository(private val apiService: GithubApiService) {
//
//    }
//}
