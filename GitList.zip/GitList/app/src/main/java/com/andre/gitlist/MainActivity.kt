package com.andre.gitlist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.navigation.fragment.NavHostFragment
import com.andre.gitlist.databinding.ActivityDetailBinding
import com.andre.gitlist.databinding.MainActivityBinding
import com.google.android.material.bottomnavigation.BottomNavigationView


class MainActivity : AppCompatActivity() {
    private var _binding: MainActivityBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)
        _binding = MainActivityBinding.inflate(layoutInflater)
        setBottomNav()

    }
    private fun setBottomNav(){
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.mainFragmentContainer) as NavHostFragment
        val navHostMainController = navHostFragment.navController
        findViewById<BottomNavigationView>(R.id.bottomNavigationView).setOnItemSelectedListener {
            when(it.itemId){
                R.id.homeFragment -> {
                    navHostMainController.navigate(R.id.homeFragment)
                    true
                }
                R.id.searchFragment -> {
                    navHostMainController.navigate(R.id.searchFragment)
                    true
                }
                R.id.profileFragment -> {
                    navHostMainController.navigate(R.id.profileFragment)
                    true
                }
                else -> {
                    false
                }
            }
        }
    }

}