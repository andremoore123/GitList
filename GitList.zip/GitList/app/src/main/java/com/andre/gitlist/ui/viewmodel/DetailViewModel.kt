package com.andre.gitlist.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.andre.gitlist.config.ApiConfig
import com.andre.gitlist.models.SearchUsers
import com.andre.gitlist.models.User
import com.andre.gitlist.service.GithubApiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class DetailViewModel: ViewModel(), CoroutineScope by MainScope() {

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _userName = MutableLiveData<String>()
    val userName: LiveData<String> = _userName

    private val _userData = MutableLiveData<User>()
    val userData: LiveData<User> = _userData

    private val _isError = MutableLiveData<Boolean>()
    val isError: LiveData<Boolean> = _isError

    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> = _errorMessage

    fun getUserData(){
        _isError.value = false
        launch {
            try{
                _isLoading.value = true
                val service = ApiConfig.getInstance().getService()
                _userData.value = service.getUserDetail(_userName.value.toString())
                _isLoading.value = false

            } catch (e: Exception){
                _isError.value = true
                _errorMessage.value = e.toString()
            }
        }
    }

    fun setUsername(userName: String){
        _userName.value = userName
    }
}